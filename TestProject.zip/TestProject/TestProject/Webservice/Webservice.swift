//
//  Webservice.swift
//  TestProject
//
//  Created by QBuser on 25/04/22.
//

import Foundation
import Combine

class WebService: NSObject {
    
    func getPosts() -> AnyPublisher<[Post],Error> {
        
        guard let url = URL(string: "https://jsonplaceholder.typicode.com/posts") else {
            fatalError("Invalid URL")
        }
        
        return Foundation.URLSession.shared.dataTaskPublisher(for: url).map { $0.data }
        .decode(type: [Post].self, decoder: JSONDecoder())
        .prefix(10)
        .receive(on: RunLoop.main)
        .eraseToAnyPublisher()
        
    }
    
    func getAllTopStories() -> AnyPublisher<[Int],Error> {
        
        guard let url = URL(string: "https://hacker-news.firebaseio.com/v0/topstories.json?print=pretty") else {
            fatalError("Invalid URL")
        }
        
        return Foundation.URLSession.shared.dataTaskPublisher(for: url)
            .print()
            .map {$0.data}
            .prefix(10)
            .decode(type: [Int].self, decoder: JSONDecoder())
            .receive(on: RunLoop.main)
            .eraseToAnyPublisher()
    }
    
    
    func getAllTopStoriesMVM(url: URL, completion: @escaping ([Post]?) -> ()) {
        let configuration = URLSessionConfiguration.default
        let session = Foundation.URLSession(configuration: configuration, delegate: self, delegateQueue: .main)
        session.dataTask(with: url, completionHandler: { data, response, error in
            if let error = error {
                print(error.localizedDescription)
                completion(nil)
            } else if let data = data {
                debugPrint(data)
                var posts = try? JSONDecoder().decode([Post].self, from: data)
                if let newposts = posts?.prefix(10) {
                    let posts = Array(newposts)
                    completion(posts)
                }
                completion(posts)
            }
            
        }).resume()
    }
}
extension WebService: URLSessionTaskDelegate, URLSessionDelegate {
   
    private func URLSession(session: URLSession, task: URLSessionTask, didCompleteWithError error: NSError?) {
        print("didCompleteWithError")
    }
    
    func urlSession(_ session: URLSession, task: URLSessionTask, didSendBodyData bytesSent: Int64, totalBytesSent: Int64, totalBytesExpectedToSend: Int64) {
        print("didSendBodyData")
        let uploadProgress: Float = Float(totalBytesSent) / Float(totalBytesExpectedToSend)
        let progressPercent = Int(uploadProgress * 100)
        print(progressPercent)
    }
    
    private func URLSession(session: URLSession, dataTask: URLSessionDataTask, didReceiveResponse response: URLResponse, completionHandler: (URLSession.ResponseDisposition) -> Void) {
        print("didReceiveResponse")
        print(response)
    }
    
    private func URLSession(session: URLSession, dataTask: URLSessionDataTask, didReceiveData data: NSData) {
        print("didReceiveData")
    }

}
