//
//  Post.swift
//  TestProject
//
//  Created by QBuser on 25/04/22.
//

import Foundation

struct Post: Codable {
    let title: String
    let body: String
}
