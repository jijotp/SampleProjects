//
//  NewsListViewController.swift
//  TestProject
//
//  Created by QBuser on 26/04/22.
//

import UIKit
import Combine

class NewsListViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    private var viewModel: PostListViewModel?
    private var webService = WebService()
    private var cancellable: AnyCancellable?
    
    private var posts = [Post]() {
        didSet {
            self.tableView.reloadData()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.registerCells()
        fetchTopStories()
        guard let url = URL(string: "https://jsonplaceholder.typicode.com/posts") else {
            fatalError("Invalid URL")
        }
        
        WebService().getAllTopStoriesMVM(url: url, completion: { articles in
            
            if let articles = articles {
                self.viewModel = PostListViewModel(post: articles)
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            }
            
        })
       
    }
    
    
    private func fetchTopStories() {
        self.cancellable =  WebService().getAllTopStories().map { storyIds in
            storyIds.map {
                StoryViewModel(id: $0)
            }
        }.sink(receiveCompletion: { _ in}, receiveValue: { storyModels in
            debugPrint(storyModels.count)
        })
    }
    
    func registerCells() {
        self.navigationItem.title = "New Title" 
        let nibTrending = UINib(nibName: "ListTableViewCell", bundle: nil)
        self.tableView.register(nibTrending, forCellReuseIdentifier: "ListTableViewCell")
        self.tableView.dataSource = self
        self.tableView.delegate = self
    }
    
}
extension NewsListViewController: UITableViewDelegate {
    
}

extension NewsListViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "ListTableViewCell", for: indexPath) as? ListTableViewCell {
            let posts = self.viewModel?.articleAtIndex(indexPath.row)
            cell.titleLabel.text = posts?.title
            cell.bodyLabel.text = posts?.body
            return cell
        }
        return UITableViewCell()
    }
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.viewModel == nil ? 0 : self.viewModel?.numberOfSection ?? 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.viewModel?.numberOfRowsInSection(section) ?? 0
    }
}
