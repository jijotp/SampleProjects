//
//  ListViewController.swift
//  TestProject
//
//  Created by QBuser on 25/04/22.
//

import UIKit
import Combine
class ListViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    private var cancellable: AnyCancellable?
    private var webService = WebService()
    
    private var posts = [Post]() {
        didSet {
            self.tableView.reloadData()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.registerCells()
        self.apiCall()
    }
    
    func registerCells() {
        let nibTrending = UINib(nibName: "ListTableViewCell", bundle: nil)
        self.tableView.register(nibTrending, forCellReuseIdentifier: "ListTableViewCell")
        self.tableView.dataSource = self
        self.tableView.delegate = self
    }
    
    func apiCall() {
        self.cancellable = self.webService.getPosts()
            .catch { _ in Just([Post]())}
            .assign(to: \.posts, on: self)
    }
}
extension ListViewController: UITableViewDelegate {
    
}

extension ListViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "ListTableViewCell", for: indexPath) as? ListTableViewCell {
            let posts = self.posts[indexPath.row]
            cell.titleLabel.text = posts.title
            cell.bodyLabel.text = posts.body
            return cell
        }
        return UITableViewCell()
    }
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.posts.count
    }
    
}
