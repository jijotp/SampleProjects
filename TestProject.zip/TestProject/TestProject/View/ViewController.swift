//
//  ViewController.swift
//  TestProject
//
//  Created by QBuser on 19/04/22.
//

import UIKit
import Combine

struct Point {
    let x: Int
    let y: Int
}

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.apiCall()
    }
    
    func getPosts() -> AnyPublisher<Data, URLError> {
        
        guard let url = URL(string: "https://jsonplaceholder.typicode.com/posts") else {
            fatalError("Invalid URL")
        }
        
        return URLSession.shared.dataTaskPublisher(for: url).map { $0.data }
        .eraseToAnyPublisher()
        
    }
    func apiCall() {
        let cancellable = getPosts().sink(receiveCompletion: { _ in }, receiveValue: { print($0) })
    }
    
    func calls() {
        //        let notification = Notification.Name("MyNotification")
        //
        //        let publisher = NotificationCenter.default.publisher(for: notification, object: nil)
        //
        //        let subscription = publisher.sink { _ in
        //            debugPrint("Notification Called")
        //
        //        }
        //
        //        NotificationCenter.default.post(name: notification, object: nil)
        //        let formatter = NumberFormatter()
        //        formatter.numberStyle = .spellOut
        //        let arrayOfInteger: [Int] = [123, 45, 67]
        //
        //        arrayOfInteger.publisher.map {
        //            formatter.string(from: NSNumber(integerLiteral: $0)) ?? ""
        //        }.sink(receiveValue: {
        //            debugPrint($0)
        //        })
        //
        //        let publisherOne = PassthroughSubject<Point, Never>()
        //
        //        publisherOne.map(\.x, \.y).sink { x, y in
        //            print("x is \(x) and y is \(y)")
        //        }
        //        publisherOne.send(Point(x: 10, y: 14))
        //
        let publisher = (1...10).publisher
        
        publisher.scan([]) { numbers, value -> [Int] in
            numbers + [value]
        }.sink {
            print($0)
        }
        
        publisher.first(where: {$0.isMultiple(of: 2) })
            .sink {
                debugPrint($0)
            }
        
        publisher.dropFirst(11)
            .sink {
                print($0)
            }
        
        let numbers = (1...5).publisher
        let publisher2 = (500...510).publisher
        //        numbers.prepend(100,101)
        //            .prepend(-1,-2)
        //            .prepend([45,67])
        //            .prepend(publisher2)
        //            .sink {
        //            print($0)
        //        }
        numbers.append(publisher2)
            .sink {
                print($0)
            }
    }
    
}

