//
//  StrotyListViewModel.swift
//  TestProject
//
//  Created by QBuser on 25/04/22.
//

import Foundation
import Combine

class StoryListViewModel: ObservableObject {
    
    var stories = [StoryViewModel]()
    private var cancellable: AnyCancellable?
    
    init() {
        fetchTopStories()
    }
    
    private func fetchTopStories() {
        WebService().getAllTopStories().map { storyIds in
            storyIds.map {
                StoryViewModel(id: $0)
            }
        }.sink(receiveCompletion: { _ in}, receiveValue: { storyModels in
            self.stories = storyModels
        })
    }
}

struct StoryViewModel {
    let id: Int
}

struct PostViewModel {
    private let post: Post
    
    init(_ post: Post) {
        self.post = post
    }
    
    var title: String {
        return self.post.title
    }
    
    var body: String {
        return self.post.body
    }
}

struct PostListViewModel {
    let post: [Post]
    
    var numberOfSection: Int {
        return 1
    }
    
    func numberOfRowsInSection(_ section: Int) -> Int {
        return self.post.count
    }
    
    func articleAtIndex(_ index: Int) -> PostViewModel {
        let post = self.post[index]
        return PostViewModel(post)
    }
}
