//
//  StoryListView.swift
//  CombineSwiftUI
//
//  Created by QBuser on 25/04/22.
//

import SwiftUI

struct StoryListView: View {
    
    @ObservedObject  private var storyListViewModel = StoryListViewModel()
    var body: some View {
        NavigationView {
            List(self.storyListViewModel.stories, id: \.id) { story in
                NavigationLink(destination: StoryDetailsView(storyId: story.id)) {
                    Text("\(story.title)")
                }
            }
            .navigationTitle("Hacker News")
        }
    }
}

struct StoryListView_Previews: PreviewProvider {
    static var previews: some View {
        StoryListView()
    }
}
