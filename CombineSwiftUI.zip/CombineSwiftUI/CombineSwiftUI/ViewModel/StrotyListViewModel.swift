//
//  StrotyListViewModel.swift
//  TestProject
//
//  Created by QBuser on 25/04/22.
//

import Foundation
import Combine

class StoryListViewModel: ObservableObject {
    
    @Published var stories = [StoryViewModel]()
    private var cancellable: AnyCancellable?
    
    init() {
        fetchTopStories()
    }
    
    private func fetchTopStories() {
        self.cancellable = WebService().getAllTopStories().map { stories in
            stories.map {
                StoryViewModel(story: $0)
            }
        }.sink(receiveCompletion: { _ in}, receiveValue: { storyModels in
            self.stories = storyModels
        })
    }
}

struct StoryViewModel {
    let story: Story
    
    var id: Int {
        return self.story.id
    }
    
    var title: String {
        return self.story.title
    }
    
    var url: String {
        return self.story.url
    }
    
}
