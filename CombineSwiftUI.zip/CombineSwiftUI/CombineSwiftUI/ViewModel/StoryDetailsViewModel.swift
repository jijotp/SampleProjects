//
//  StoryDetailsViewModel.swift
//  CombineSwiftUI
//
//  Created by QBuser on 25/04/22.
//

import Foundation
import Combine
class StoryDetailsViewModel: ObservableObject {
    
    private var cancellable: AnyCancellable?
    
    @Published  private var story = Story.placeholder()
    
    func fetchStoryDetails(storyId: Int) {
         print("about to make a network request")
        self.cancellable = WebService().getStoryById(storyId: storyId)
                  .catch { _ in Just(Story.placeholder()) }
                  .sink(receiveCompletion: { _ in }, receiveValue: { story in
                      self.story = story
        })
    }
}

extension StoryDetailsViewModel {
    
    var title: String {
        return self.story.title
    }
    
    var url: String {
        return self.story.url
    }
}
