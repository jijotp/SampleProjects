//
//  CombineSwiftUIApp.swift
//  CombineSwiftUI
//
//  Created by QBuser on 25/04/22.
//

import SwiftUI

@main
struct CombineSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            StoryListView()
        }
    }
}
