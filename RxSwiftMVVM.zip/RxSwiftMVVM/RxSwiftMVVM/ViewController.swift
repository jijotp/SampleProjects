//
//  ViewController.swift
//  RxSwiftMVVM
//
//  Created by QBuser on 28/04/22.
//

import UIKit
import RxSwift

class ViewController: UIViewController {
    
    var cartQuantity = PublishSubject<Int>()
    
    var quantity = BehaviorSubject<Int>(value: 1)
    
    var cartArray = PublishSubject<[Int]>()
    private let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let value1 =  Observable.of(1, 2, 3)
        
        let value2 =  Observable.just(1)
        
        let value3 =  Observable.just([1, 2, 3])
        
        let value4 =  Observable.from([1, 2, 3])
        
        value4.subscribe{ event in
            print(event)
        }
        
        value4.subscribe{ event in
            if let element = event.element {
                debugPrint(element)
            }
        }
        
        value3.subscribe{ event in
            print(event)
        }
        
        value3.subscribe{ event in
            if let element = event.element {
                debugPrint(element)
            }
        }
        
        value4.subscribe(onNext: { element in
            debugPrint(element)
            
        })
        cartQuantity.subscribe(onNext: { (qty) in
             debugPrint(qty)
            }).disposed(by: disposeBag)
        cartQuantity.onNext(10)
        
        cartArray.subscribe(onNext: { (qty) in
             debugPrint(qty)
            }).disposed(by: disposeBag)
        cartArray.onNext([10, 100])
        cartArray.onNext([10, 100,1000])
        
        quantity.subscribe(onNext: { (qty) in
             debugPrint(qty)
            }).disposed(by: disposeBag)
        quantity.onNext(10)
        
    }
    
}

