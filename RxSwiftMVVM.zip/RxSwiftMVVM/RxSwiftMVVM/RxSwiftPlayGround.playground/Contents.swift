import UIKit
import RxSwift


let value1 =  Observable.of(1, 2, 3)

let value2 =  Observable.just(1)

let value3 =  Observable.just([1, 2, 3])

let value4 =  Observable.from([1, 2, 3])

value4.subscribe{ event in
    print(event)
}
