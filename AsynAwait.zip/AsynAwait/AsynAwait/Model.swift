//
//  Model.swift
//  AsynAwait
//
//  Created by QBuser on 11/05/22.
//

import Foundation


struct News : Codable, Identifiable {
    var id = UUID()
    let title : String?
    let publication : String?
    let imageURL : String?

    enum CodingKeys: String, CodingKey {

        case title = "title"
        case publication = "publication"
        case imageURL = "imageURL"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        title = try values.decodeIfPresent(String.self, forKey: .title)
        publication = try values.decodeIfPresent(String.self, forKey: .publication)
        imageURL = try values.decodeIfPresent(String.self, forKey: .imageURL)
    }

}
