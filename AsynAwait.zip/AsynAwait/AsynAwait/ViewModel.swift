//
//  ViewModel.swift
//  AsynAwait
//
//  Created by QBuser on 03/05/22.
//

import Foundation


@MainActor
class NewsSourceListViewModel: ObservableObject {
    
    @Published var newsSources: [NewsSourceViewModel] = []
    
     func fetchNewsAsync() {
        if #available(iOS 13.0, *) {
            Task {
                do {
                    let posts = try await WebService().getPosts(with: [News].self)
                    if let news = posts as? [News] {
                        self.newsSources = news.map(NewsSourceViewModel.init)
                        debugPrint(self.newsSources.count)
                    }
                } catch {
                    print(error)
                }
            }
        } else {
            // Fallback on earlier versions
        }
    }
    
}

struct NewsSourceViewModel {
    let news: News
    
    init(weather: News) {
        self.news = weather
    }
    var id: UUID {
        return news.id
    }
    
    var title: String {
        return news.title ?? ""
    }
    
    var publication: String {
        return news.publication ?? ""
    }
    
}
