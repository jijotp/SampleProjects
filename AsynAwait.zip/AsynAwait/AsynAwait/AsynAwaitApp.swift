//
//  AsynAwaitApp.swift
//  AsynAwait
//
//  Created by QBuser on 03/05/22.
//

import SwiftUI

@main
struct AsynAwaitApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
