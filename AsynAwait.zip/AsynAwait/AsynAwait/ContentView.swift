//
//  ContentView.swift
//  AsynAwait
//
//  Created by QBuser on 03/05/22.
//

import SwiftUI

struct ContentView: View {
    @ObservedObject private var storyListVM = NewsSourceListViewModel()
    
    var body: some View {
        NavigationView {
            List(self.storyListVM.newsSources, id: \.id) { storyVM in
                    Text("\(storyVM.id)")
            }
            
        .navigationBarTitle("Hacker News")
        }.task {
            storyListVM.fetchNewsAsync()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
