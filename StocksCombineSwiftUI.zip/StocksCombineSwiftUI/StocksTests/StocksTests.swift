//
//  StocksTests.swift
//  StocksTests
//
//  Created by QBuser on 27/04/22.
//

import XCTest
@testable import Stocks

class StocksTests: XCTestCase {

    func test_AddTwoNumber() {
        let calculator = Calculator()
        let result = calculator.add(5, 10)
        
        XCTAssertEqual(result, 15)
    }

}
