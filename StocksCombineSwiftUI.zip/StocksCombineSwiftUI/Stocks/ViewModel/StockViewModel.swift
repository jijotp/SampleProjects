//
//  StockViewModel.swift
//  Stocks
//
//  Created by QBuser on 27/04/22.
//

import Foundation

struct StockViewModel {
    
    let stock: Stock
    
    var symbol: String {
        return self.stock.symbol.uppercased()
    }
    
    var description: String {
        return self.stock.description
    }
    
    var price: String {
        return String(self.stock.price)
    }
    
    var change: String {
        return self.stock.change
    }
}


struct ArticleListViewModel {
    
    let article: Article
    
    var imageURL: String {
        return self.article.imageURL
    }
    
    var title: String {
        return self.article.title
    }
    
    var publication: String {
        return self.article.publication.uppercased()
    }
    
}
