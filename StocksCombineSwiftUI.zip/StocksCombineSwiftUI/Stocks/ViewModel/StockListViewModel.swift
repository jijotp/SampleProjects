//
//  StockListViewModel.swift
//  Stocks
//
//  Created by QBuser on 27/04/22.
//

import Foundation
import SwiftUI
@MainActor
class StockListViewModel: ObservableObject {
    
    @Published var searchTerm: String = ""
    @Published var dragOffset: CGSize = CGSize(width: 0, height: 650)
    @Published var stocks = [StockViewModel]()
    @Published var news = [ArticleListViewModel]()
    
    func load() {
        self.fetchStocks()
        self.fetchNews()
        self.fetchNewsAsync()
    }
    
    private func fetchStocks() {
        WebService().getStocks(completion: { result in
            
            switch result {
            case .success(let stocks):
                guard let stock = stocks as? [Stock] else {
                    return
                }
                DispatchQueue.main.async {
                    self.stocks = stock.map(StockViewModel.init)
                }
            case .failure(let error):
                debugPrint(error.localizedDescription)
            }
            
        })
    }
    
    private func fetchNews() {
        WebService().getNews(with: [Article].self) { result in
            
            switch result {
            case .success(let stocks):
                DispatchQueue.main.async {
                    if let news = stocks as? [Article] {
                        self.news = news.map(ArticleListViewModel.init)
                        debugPrint(self.news.count)
                    }
                }
            case .failure(let error):
                debugPrint(error.localizedDescription)
            }
            
        }
    }
    
    private func fetchNewsAsync() {
        Task {
            do {
                let posts = try await WebService().getPosts(with: [Article].self)
                    if let news = posts as? [Article] {
                        self.news = news.map(ArticleListViewModel.init)
                        debugPrint(self.news.count)
                }
            } catch {
                print(error)
            }
        }
    }
    
}
