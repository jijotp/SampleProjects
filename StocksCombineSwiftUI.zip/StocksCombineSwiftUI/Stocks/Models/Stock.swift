//
//  Stock.swift
//  Stocks
//
//  Created by QBuser on 27/04/22.
//

import Foundation

struct Stock: Decodable {
    let symbol: String
    let description: String
    let price: Int
    let change: String
}

struct Article: Decodable {
    let title: String
    let imageURL: String
    let publication: String
}


class Calculator {
    
    func add(_ a: Int, _ b :Int) -> Int {
        return a+b
    }
}
