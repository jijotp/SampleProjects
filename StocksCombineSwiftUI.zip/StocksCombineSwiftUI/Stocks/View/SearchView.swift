//
//  SearchView.swift
//  Stocks
//
//  Created by QBuser on 27/04/22.
//

import SwiftUI

struct SearchView: View {
    
    @Binding var name: String
    var body: some View {
        HStack {
            Spacer()
            Image(systemName: "magnifyingglass")
            TextField("Search", text: $name)
                .foregroundColor(Color.primary)
                .padding(10)
            Spacer()
        }.background(Color.secondary.background())
            .foregroundColor(.secondary)
            .cornerRadius(20)
            .padding(10)
    }
}

struct SearchView_Previews: PreviewProvider {
    static var previews: some View {
        SearchView(name: .constant(""))
    }
}
