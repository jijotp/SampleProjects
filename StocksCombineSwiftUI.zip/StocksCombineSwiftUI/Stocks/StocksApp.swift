//
//  StocksApp.swift
//  Stocks
//
//  Created by QBuser on 27/04/22.
//

import SwiftUI

@main
struct StocksApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
