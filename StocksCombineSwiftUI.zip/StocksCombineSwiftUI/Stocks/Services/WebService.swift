//
//  WebService.swift
//  Stocks
//
//  Created by QBuser on 27/04/22.
//

import Foundation

class WebService {
    
    func getStocks(completion: @escaping (Result<[Any], WebServiceError>) -> Void) {
        
        guard let url = URL(string: "https://island-bramble.glitch.me/stocks") else {
            completion(.failure(.badURL))
            return
        }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            
            guard let data = data, error == nil else {
                completion(.failure(.apiError))
                return
            }
            
            if let stocks = try? JSONDecoder().decode([Stock].self, from: data) {
                completion(.success(stocks))
            } else {
                completion(.failure(.decodeError))
            }
            
        }.resume()
        
    }
    
    func getNews<T: Decodable>(with type: T.Type, completion: @escaping (new) -> Void) {
        
        guard let url = URL(string: "https://island-bramble.glitch.me/top-news") else {
            completion(.failure(.badURL))
            return
        }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            
            guard let data = data, error == nil else {
                completion(.failure(.apiError))
                return
            }
            
            if let stocks = try? JSONDecoder().decode(T.self, from: data) {
                completion(.success(stocks))
            } else {
                completion(.failure(.decodeError))
            }
            
        }.resume()
        
    }
    
    func getPosts<T: Decodable>(with type: T.Type) async throws -> Any {
        return try await withCheckedThrowingContinuation { continuation in
            getNews(with: type) { result in
                switch result {
                case .success(let posts):
                    continuation.resume(returning: posts)
                case .failure(let error):
                    continuation.resume(throwing: error)
                }
            }
        }
        
    }
    
    func getNews<T: Decodable>(with type: T.Type) async throws -> Any? {
        
        guard let url = URL(string: "https://island-bramble.glitch.me/top-news") else {
            fatalError("Url is incorrect!")
        }
        
        let (data, response) = try await URLSession.shared.data(from: url)
        return try? JSONDecoder().decode(T.self, from: data)
    }
}
typealias new = (Result<Any, WebServiceError>)
enum WebServiceError: Error {
    case badURL
    case decodeError
    case apiError
}
