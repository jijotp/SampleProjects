//
//  View.swift
//  ViperExample
//
//  Created by QBuser on 10/05/22.
//

import Foundation
import UIKit

protocol AnyView: AnyObject {
    var presenter : AnyPresenter? {get set}
    func update(with cryptos: [Article])
    func update(with error: WebServiceError)
}

