//
//  interactor.swift
//  ViperExample
//
//  Created by QBuser on 10/05/22.
//

import Foundation

typealias new = (Result<Any, WebServiceError>)
enum WebServiceError: Error {
    case badURL
    case decodeError
    case apiError
}
protocol AnyInteractor {
    var presenter : AnyPresenter? {get set}
    func getNewsData()
}


class InfoInteractor: AnyInteractor {
    var presenter: AnyPresenter?
    
    func getNewsData() {
        webService().getNews(with: [Article].self, url: "https://api.sampleapis.com/beers/ale") { result in
            switch result {
            case .success(let stocks):
                if let stock = stocks as? [Article] {
                    self.presenter?.interactorDidDownloadInfo(result: .success(stock))
                    return
                }
                self.presenter?.interactorDidDownloadInfo(result: .success([]))
            case .failure(let error):
                self.presenter?.interactorDidDownloadInfo(result: .failure(error))
            }
            
        }
    }
}

class webService {
    func getNews<T: Decodable>(with type: T.Type, url: String, completion: @escaping (new) -> Void) {
        
        guard let url = URL(string: url) else {
            completion(.failure(.badURL))
            return
        }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            
            guard let data = data, error == nil else {
                completion(.failure(.apiError))
                return
            }
            
            if let stocks = try? JSONDecoder().decode(T.self, from: data) {
                completion(.success(stocks))
            } else {
                completion(.failure(.decodeError))
            }
            
        }.resume()
    }
}
