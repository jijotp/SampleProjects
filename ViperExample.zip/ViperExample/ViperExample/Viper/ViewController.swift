//
//  ViewController.swift
//  ViperExample
//
//  Created by QBuser on 10/05/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    var presenter: AnyPresenter?
    var news: [Article] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .red
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        self.tableView.delegate = self
        self.tableView.dataSource = self
        // Do any additional setup after loading the view.
    }
}
extension ViewController: AnyView {
    
    func update(with cryptos: [Article]) {
        debugPrint(cryptos.count)
        DispatchQueue.main.async {
            self.news = cryptos
            self.tableView.reloadData()
            self.tableView.isHidden = false
        }
    }
    
    func update(with error: WebServiceError) {
    }
}
extension ViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return news.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        var content = cell.defaultContentConfiguration()
        content.text = news[indexPath.row].name
        content.secondaryText = news[indexPath.row].price
        cell.contentConfiguration = content
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(news[indexPath.row].image)
    }
}
