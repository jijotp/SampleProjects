//
//  Presenter.swift
//  ViperExample
//
//  Created by QBuser on 10/05/22.
//

import Foundation
protocol AnyPresenter {
    var router : AnyRouter? { get set }
    var interactor : AnyInteractor? {get set}
    var view : AnyView? {get set}
    
    func interactorDidDownloadInfo(result: Result<[Article], WebServiceError>)
}

class InfoPresenter : AnyPresenter {
    var router: AnyRouter?
    
    var view: AnyView?
    
    var interactor: AnyInteractor? {
        didSet {
            interactor?.getNewsData()
        }
    }
    
    func interactorDidDownloadInfo(result: Result<[Article], WebServiceError>) {
        switch result {
        case .success(let cryptos):
            view?.update(with: cryptos)
        case .failure(let error):
            view?.update(with: error)
        }
    }
    
}
