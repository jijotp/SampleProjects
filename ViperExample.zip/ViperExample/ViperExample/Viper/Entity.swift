//
//  Entity.swift
//  ViperExample
//
//  Created by QBuser on 10/05/22.
//

import Foundation

struct Article: Codable {
    let price : String?
    let name : String?
    let rating : Rating?
    let image : String?
    let id : Int?
}

struct Rating : Codable {
    let average : Double?
    let reviews : Int?
}
