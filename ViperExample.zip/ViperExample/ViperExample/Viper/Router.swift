//
//  Router.swift
//  ViperExample
//
//  Created by QBuser on 10/05/22.
//

import Foundation
import UIKit

// Class
// We setup every component here to orchestrate and route the application

typealias EntryPoint = AnyView & UIViewController

protocol AnyRouter {
    var entry : EntryPoint? {get}
    static func startExecution() -> AnyRouter
}

class CryptoRouter : AnyRouter {
    var entry: EntryPoint?
    
    static func startExecution() -> AnyRouter {
        
        let router = CryptoRouter()
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "ViewController") as! ViewController 
        
        var view : AnyView = vc
        var presenter : AnyPresenter = InfoPresenter()
        var interactor : AnyInteractor = InfoInteractor()
        
        view.presenter = presenter
        
        presenter.view = view
        presenter.router = router
        presenter.interactor = interactor
        
        interactor.presenter = presenter
        
        router.entry = view as? EntryPoint
        
        return router
        
    }
    
}
